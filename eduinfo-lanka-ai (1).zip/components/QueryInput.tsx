
import React, { useState, useEffect, useRef } from 'react';
import { Language, ISpeechRecognitionInstance, SpeechRecognitionConstructor, ISpeechRecognitionEvent, ISpeechRecognitionErrorEvent } from '../types';
import { UI_TEXTS, BCP_47_LANGUAGE_CODES } from '../constants';

interface QueryInputProps {
  onSubmit: (query: string) => void;
  isLoading: boolean;
  currentLanguage: Language;
}

const MicrophoneIcon: React.FC<{ active?: boolean; className?: string }> = ({ active, className }) => (
  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" className={`w-6 h-6 ${active ? 'text-red-600 animate-pulse' : 'text-slate-500 hover:text-indigo-600'} ${className}`}>
    <path d="M12 18.75a6 6 0 006-6v-1.5a6 6 0 00-12 0v1.5a6 6 0 006 6zM12 5.25a.75.75 0 01.75.75v4.5a.75.75 0 01-1.5 0v-4.5A.75.75 0 0112 5.25z" />
    <path d="M10.5 18.75A.75.75 0 0011.25 18v-1.5a.75.75 0 00-1.5 0v1.5a.75.75 0 00.75.75zM12 18.75a.75.75 0 01.75-.75v-1.5a.75.75 0 01-1.5 0v1.5A.75.75 0 0112 18.75zM12.75 18A.75.75 0 0013.5 18.75v-1.5a.75.75 0 00-1.5 0v1.5a.75.75 0 00.75.75z" />
    <path fillRule="evenodd" d="M12 21a8.25 8.25 0 008.25-8.25V9.75A8.25 8.25 0 0012 1.5a8.25 8.25 0 00-8.25 8.25v3A8.25 8.25 0 0012 21zm0-1.5A6.75 6.75 0 005.25 12.75V9.75a6.75 6.75 0 0113.5 0v3A6.75 6.75 0 0012 19.5z" clipRule="evenodd" />
  </svg>
);


const QueryInput: React.FC<QueryInputProps> = ({ onSubmit, isLoading, currentLanguage }) => {
  const [query, setQuery] = useState('');
  const [isListening, setIsListening] = useState(false);
  const [speechError, setSpeechError] = useState<string | null>(null);
  const recognitionRef = useRef<ISpeechRecognitionInstance | null>(null);
  const uiTexts = UI_TEXTS[currentLanguage];

  const SpeechRecognitionAPI: SpeechRecognitionConstructor | undefined = window.SpeechRecognition || window.webkitSpeechRecognition;
  const browserSupportsSpeech = !!SpeechRecognitionAPI;

  useEffect(() => {
    if (!SpeechRecognitionAPI) return;

    const recognition: ISpeechRecognitionInstance = new SpeechRecognitionAPI();
    recognition.continuous = false;
    recognition.interimResults = true;
    recognition.lang = BCP_47_LANGUAGE_CODES[currentLanguage];

    recognition.onresult = (event: ISpeechRecognitionEvent) => {
      let interimTranscript = '';
      let finalTranscript = '';
      for (let i = event.resultIndex; i < event.results.length; ++i) {
        if (event.results[i].isFinal) {
          finalTranscript += event.results[i][0].transcript;
        } else {
          interimTranscript += event.results[i][0].transcript;
        }
      }
      setQuery(finalTranscript || interimTranscript);
      // Removed auto-submit on final transcript for better user control
    };

    recognition.onerror = (event: ISpeechRecognitionErrorEvent) => {
      if (event.error === 'no-speech' || event.error === 'audio-capture' || event.error === 'network') {
        setSpeechError(uiTexts.voiceInputError);
      } else if (event.error === 'not-allowed') {
        setSpeechError(uiTexts.voiceInputPermissionDenied);
      } else {
        setSpeechError(`${uiTexts.voiceInputError}: ${event.error}`);
      }
      setIsListening(false);
    };

    recognition.onend = () => {
      setIsListening(false);
    };

    recognitionRef.current = recognition;

    return () => {
      if (recognitionRef.current) {
        recognitionRef.current.stop();
      }
    };
  }, [currentLanguage, SpeechRecognitionAPI, uiTexts]);

  const handleToggleListening = () => {
    if (!browserSupportsSpeech || !recognitionRef.current) {
      setSpeechError(uiTexts.voiceInputNotSupported);
      return;
    }
    if (isListening) {
      recognitionRef.current.stop();
      setIsListening(false);
    } else {
      setSpeechError(null); 
      try {
        setQuery(''); // Clear query field before starting new recognition
        recognitionRef.current.start();
        setIsListening(true);
      } catch (e) {
        console.error("Error starting speech recognition:", e);
        setSpeechError(uiTexts.voiceInputError);
        setIsListening(false);
      }
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (query.trim() && !isLoading) {
      onSubmit(query.trim());
      // setQuery(''); // Retain query in box after submission for user reference
    }
  };

  let voiceButtonTitle = uiTexts.voiceInputEnable;
  if(!browserSupportsSpeech) voiceButtonTitle = uiTexts.voiceInputNotSupported;
  else if (isListening) voiceButtonTitle = uiTexts.voiceInputDisable;


  return (
    <form onSubmit={handleSubmit} className="mt-4 mb-8">
      <div className="flex flex-col sm:flex-row items-stretch gap-3">
        <div className="flex-grow relative">
          <textarea
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder={isListening ? uiTexts.voiceInputListening : uiTexts.queryPlaceholder}
            rows={3}
            className="w-full p-3.5 pr-14 border border-slate-300 rounded-xl shadow-sm focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 transition-all resize-none bg-white text-slate-800 placeholder-slate-400"
            disabled={isLoading}
            aria-label={uiTexts.queryPlaceholder}
          />
          {browserSupportsSpeech && (
            <button
              type="button"
              onClick={handleToggleListening}
              disabled={isLoading}
              className="absolute right-3 top-1/2 -translate-y-1/2 p-2 rounded-full hover:bg-slate-100 focus:outline-none focus:ring-2 focus:ring-indigo-400 disabled:opacity-50 transition-colors"
              title={voiceButtonTitle}
              aria-pressed={isListening}
            >
              <MicrophoneIcon active={isListening} />
            </button>
          )}
        </div>
        <button
          type="submit"
          disabled={isLoading || !query.trim()}
          className="bg-indigo-600 hover:bg-indigo-700 text-white font-semibold py-3.5 px-8 rounded-xl shadow-md hover:shadow-lg focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:ring-opacity-70 transition-all disabled:opacity-60 disabled:cursor-not-allowed"
        >
          {isLoading ? (
            <span className="flex items-center justify-center">
              <svg className="animate-spin -ml-1 mr-3 h-5 w-5 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
              </svg>
              {uiTexts.loading}
            </span>
          ) : uiTexts.submitButton}
        </button>
      </div>
      {speechError && <p className="text-sm text-red-600 mt-1.5 px-1">{speechError}</p>}
      {!browserSupportsSpeech && !isLoading && <p className="text-sm text-orange-600 mt-1.5 px-1">{uiTexts.voiceInputNotSupported}</p>}
    </form>
  );
};

export default QueryInput;
