import React from 'react';
import { Language } from '../types';
import { UI_TEXTS, APP_LOGO_BASE64 } from '../constants';
import LanguageSelector from './LanguageSelector';

interface HeaderProps {
  currentLanguage: Language;
  onLanguageChange: (language: Language) => void;
  onNewChat: () => void;
}

const NewChatIcon: React.FC<{ className?: string }> = ({ className }) => (
  <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.8} stroke="currentColor" className={`w-5 h-5 ${className}`}>
    <path strokeLinecap="round" strokeLinejoin="round" d="M16.023 9.348h4.992v-.001M2.985 19.644v-4.992m0 0h4.992m-4.993 0l3.181 3.183a8.25 8.25 0 0013.803-3.7M4.031 9.865a8.25 8.25 0 0113.803-3.7l3.181 3.183m0-4.991v4.99" />
  </svg>
);


const Header: React.FC<HeaderProps> = ({ currentLanguage, onLanguageChange, onNewChat }) => {
  const uiTexts = UI_TEXTS[currentLanguage];

  return (
    <header className="bg-white/80 backdrop-blur-md shadow-lg p-4 sticky top-0 z-50">
      <div className="container mx-auto flex flex-col sm:flex-row justify-between items-center">
        <div className="text-center sm:text-left mb-4 sm:mb-0">
          <div className="flex items-center justify-center sm:justify-start">
            <img 
              src={APP_LOGO_BASE64} 
              alt="App Logo" 
              className="w-10 h-10 mr-3 object-contain" // Adjusted size and margin
            />
            <h1 className="text-2xl font-bold text-indigo-700">{uiTexts.headerTitle}</h1>
          </div>
          <p className="text-xs text-slate-600 sm:ml-14">{uiTexts.headerSubtitle}</p> {/* Adjusted margin for subtitle */}
        </div>
        <div className="flex items-center space-x-3 sm:space-x-4">
          <LanguageSelector selectedLanguage={currentLanguage} onChangeLanguage={onLanguageChange} />
          <button
            onClick={onNewChat}
            className="p-2.5 bg-green-500 hover:bg-green-600 text-white rounded-lg shadow hover:shadow-md transition-all text-sm font-medium flex items-center"
            title={uiTexts.newChat}
            aria-label={uiTexts.newChat}
          >
            <NewChatIcon className="mr-1.5" />
            {uiTexts.newChat}
          </button>
        </div>
      </div>
    </header>
  );
};

export default Header;