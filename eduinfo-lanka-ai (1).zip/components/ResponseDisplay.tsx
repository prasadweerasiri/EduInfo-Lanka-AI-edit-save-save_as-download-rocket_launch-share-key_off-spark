import React, { useState, useEffect, useRef } from 'react';
import { AppMessage, Language } from '../types';
import { UI_TEXTS, BCP_47_LANGUAGE_CODES } from '../constants';
import SourceLink, { PrintableSourceLink } from './SourceLink';

const SpeakerPlayIcon: React.FC<{ className?: string }> = ({ className }) => (
  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" className={`w-5 h-5 ${className}`}>
    <path d="M8.25 4.5a3.75 3.75 0 00-3.75 3.75v6a3.75 3.75 0 003.75 3.75h3.75a3.75 3.75 0 003.75-3.75V8.25a3.75 3.75 0 00-3.75-3.75H8.25zM16.5 8.25a3.75 3.75 0 11-7.5 0 3.75 3.75 0 017.5 0zM20.25 12a3.75 3.75 0 11-7.5 0 3.75 3.75 0 017.5 0z"/>
    <path fillRule="evenodd" d="M2.25 12c0-5.03 4.038-9.102 9.022-9.129a.75.75 0 01.728.728A9.123 9.123 0 0012 21.75a.75.75 0 01-.728-.728A9.102 9.102 0 012.25 12z" clipRule="evenodd"/>
    <path d="M17.25 12a.75.75 0 01.75-.75h2.25a.75.75 0 010 1.5H18a.75.75 0 01-.75-.75z"/>
  </svg>
);

const SpeakerStopIcon: React.FC<{ className?: string }> = ({ className }) => (
 <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" className={`w-5 h-5 ${className}`}>
  <path fillRule="evenodd" d="M12 2.25c-5.385 0-9.75 4.365-9.75 9.75s4.365 9.75 9.75 9.75 9.75-4.365 9.75-9.75S17.385 2.25 12 2.25zm-1.72 6.97a.75.75 0 00-1.06 1.06L10.94 12l-1.72 1.72a.75.75 0 101.06 1.06L12 13.06l1.72 1.72a.75.75 0 101.06-1.06L13.06 12l1.72-1.72a.75.75 0 10-1.06-1.06L12 10.94l-1.72-1.72z" clipRule="evenodd" />
</svg>
);

const PrintIcon: React.FC<{ className?: string }> = ({ className }) => (
  <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className={`w-5 h-5 ${className}`}>
    <path strokeLinecap="round" strokeLinejoin="round" d="M6.72 13.829c-.24.03-.48.062-.72.096m.72-.096a8.25 8.25 0 018.25-6.039m-8.25 6.039L3 16.5m1.5-15l.673 1.346M21 16.5l-2.5-5M21 16.5l-2.5-5M21 16.5v-3.375c0-.621-.504-1.125-1.125-1.125h-2.25c-.621 0-1.125.504-1.125 1.125V16.5m-9-9.375c0-.621.504-1.125 1.125-1.125h2.25c.621 0 1.125.504 1.125 1.125V16.5m-4.5 0h9" />
  </svg>
);

const SaveIcon: React.FC<{ className?: string }> = ({ className }) => (
  <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className={`w-5 h-5 ${className}`}>
    <path strokeLinecap="round" strokeLinejoin="round" d="M3 16.5v2.25A2.25 2.25 0 005.25 21h13.5A2.25 2.25 0 0021 18.75V16.5M16.5 12L12 16.5m0 0L7.5 12m4.5 4.5V3" />
  </svg>
);


const stripMarkdownForSpeech = (markdownText: string): string => {
  let plainText = markdownText;
  plainText = plainText.replace(/^###\s+/gm, '');
  plainText = plainText.replace(/^##\s+/gm, '');
  plainText = plainText.replace(/^#\s+/gm, '');
  plainText = plainText.replace(/\*\*(.*?)\*\*/g, '$1');
  plainText = plainText.replace(/\*(.*?)\*/g, '$1');
  plainText = plainText.replace(/^[\*\-\+]\s+/gm, '');
  plainText = plainText.replace(/```[\s\S]*?```/g, ''); 
  plainText = plainText.replace(/`([^`]+)`/g, '$1');
  plainText = plainText.replace(/\[([^\]]+)\]\([^\)]+\)/g, '$1');
  plainText = plainText.replace(/\n\s*\n/g, '. ');
  plainText = plainText.replace(/\n/g, ' ');
  plainText = plainText.replace(/\s+/g, ' ').trim();
  return plainText;
};

const SimpleMarkdownRenderer: React.FC<{ text: string }> = ({ text }) => {
  const lines = text.split('\n');
  const elements: React.ReactNode[] = [];
  let currentListItems: React.ReactNode[] = [];
  let inList = false;

  const flushList = (keySuffix: string) => {
    if (inList && currentListItems.length > 0) {
      elements.push(
        <ul key={`ul-${keySuffix}`} className="list-disc list-inside pl-4 my-2 space-y-1 text-slate-700">
          {currentListItems}
        </ul>
      );
    }
    currentListItems = [];
    inList = false;
  };

  lines.forEach((line, index) => {
    const key = `md-${index}-${Math.random().toString(36).substring(7)}`;

    const processInlineFormatting = (inlineText: string): string => {
      let processed = inlineText.replace(/\*\*(.*?)\*\*/g, '<strong class="font-semibold text-slate-800">$1</strong>');
      processed = processed.replace(/\*(.*?)\*/g, '<em class="italic">$1</em>');
      processed = processed.replace(/`([^`]+)`/g, '<code class="bg-slate-200 text-slate-700 px-1.5 py-0.5 rounded text-sm font-mono">$1</code>');
      processed = processed.replace(/\[([^\]]+)\]\(([^)]+)\)/g, '<a href="$2" target="_blank" rel="noopener noreferrer" class="text-indigo-600 hover:text-indigo-700 hover:underline">$1</a>');
      return processed;
    };

    if (line.startsWith('### ')) {
      flushList(`${key}-pre-h3`);
      elements.push(<h3 key={key} className="text-lg font-semibold mt-3 mb-1.5 text-slate-800" dangerouslySetInnerHTML={{ __html: processInlineFormatting(line.substring(4)) }} />);
    } else if (line.startsWith('## ')) {
      flushList(`${key}-pre-h2`);
      elements.push(<h2 key={key} className="text-xl font-semibold mt-4 mb-2 text-slate-800" dangerouslySetInnerHTML={{ __html: processInlineFormatting(line.substring(3)) }} />);
    } else if (line.startsWith('# ')) {
      flushList(`${key}-pre-h1`);
      elements.push(<h1 key={key} className="text-2xl font-semibold mt-4 mb-2 text-slate-800" dangerouslySetInnerHTML={{ __html: processInlineFormatting(line.substring(2)) }} />);
    } else if (line.startsWith('* ') || line.startsWith('- ') || /^\d+\.\s/.test(line)) {
      if (!inList) {
        inList = true; 
      }
      const itemContent = line.replace(/^[\*\-\+]\s+|^\d+\.\s+/, "");
      currentListItems.push(<li key={key} className="mb-1" dangerouslySetInnerHTML={{ __html: processInlineFormatting(itemContent) }} />);
    } else if (line.trim() === '') {
      flushList(`${key}-pre-br`);
      if (elements.length > 0) {
        const lastPushedNode = elements[elements.length - 1];
        if (!(React.isValidElement(lastPushedNode) && lastPushedNode.type === 'br')) {
          elements.push(<br key={key} />);
        }
      }
    } else { 
      flushList(`${key}-pre-p`);
      elements.push(<p key={key} className="mb-2.5 text-slate-700" dangerouslySetInnerHTML={{ __html: processInlineFormatting(line) }} />);
    }
  });

  flushList('final'); 

  return <div className="prose prose-sm sm:prose-base max-w-none break-words">{elements}</div>;
};


interface ResponseDisplayProps {
  message: AppMessage;
  currentLanguage: Language;
}

const ResponseDisplay: React.FC<ResponseDisplayProps> = ({ message, currentLanguage }) => {
  const uiTexts = UI_TEXTS[currentLanguage];
  const [isSpeaking, setIsSpeaking] = useState(false);
  const utteranceRef = useRef<SpeechSynthesisUtterance | null>(null);
  
  const browserSupportsSpeechSynthesis = 'speechSynthesis' in window;

  useEffect(() => {
    return () => {
      if (window.speechSynthesis && window.speechSynthesis.speaking) {
        window.speechSynthesis.cancel();
      }
      setIsSpeaking(false);
    };
  }, [message.id]);

  const handleToggleSpeak = () => {
    if (!browserSupportsSpeechSynthesis) {
      alert(uiTexts.speechSynthesisNotSupported);
      return;
    }

    if (isSpeaking) {
      window.speechSynthesis.cancel();
      setIsSpeaking(false);
    } else {
      const textToSpeak = stripMarkdownForSpeech(message.text);
      const utterance = new SpeechSynthesisUtterance(textToSpeak);
      const targetLang = BCP_47_LANGUAGE_CODES[currentLanguage];
      utterance.lang = targetLang;
      
      const setVoice = () => {
        const voices = window.speechSynthesis.getVoices();
        // Ensure voices are loaded before trying to find one
        if (voices.length === 0) {
          // This can happen if onvoiceschanged hasn't fired yet or if no voices are available at all
          console.warn("SpeechSynthesis: No voices loaded yet. Waiting for onvoiceschanged or using browser default for the lang.");
          // The browser will attempt to use utterance.lang even if no specific voice is set.
          return; 
        }

        const selectedVoice = voices.find(voice => voice.lang === targetLang);
        if (selectedVoice) {
          utterance.voice = selectedVoice;
          // console.log(`SpeechSynthesis: Using voice "${selectedVoice.name}" for language ${targetLang}.`);
        } else {
          console.warn(`SpeechSynthesis: No specific voice found for language ${targetLang}. The browser will attempt to use a default voice for this language if available, or fall back to its overall default voice.`);
        }
      };

      // Voices might not be loaded immediately.
      if (window.speechSynthesis.getVoices().length > 0) {
        setVoice();
      } else {
        window.speechSynthesis.onvoiceschanged = setVoice;
      }
      
      utterance.onend = () => setIsSpeaking(false);
      utterance.onerror = (event) => {
        console.error('Speech synthesis error:', event);
        setIsSpeaking(false);
      };
      
      utteranceRef.current = utterance;
      window.speechSynthesis.speak(utterance);
      setIsSpeaking(true);
    }
  };

  const handlePrint = () => {
    window.print();
  };

  const handleSave = () => {
    let contentToSave = message.text;
    const webSources = message.sources?.filter(s => s.web).map(s => s.web!) || [];

    if (webSources.length > 0) {
        const sourcesMarkdown = `\n\n---\n\n**${uiTexts.sourcesTitle}**\n\n` +
                                webSources.map(s => `- [${s.title || s.uri}](${s.uri})`).join('\n');
        contentToSave += sourcesMarkdown;
    }

    const blob = new Blob([contentToSave], { type: 'text/markdown;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    const timestamp = new Date().toISOString().replace(/:/g, '-').slice(0, 19);
    link.download = `eduinfo-lanka-answer-${timestamp}.md`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  };

  if (message.role === 'system' || message.role === 'user') {
    return null;
  }

  if (message.role === 'error') {
    return (
        <div className="bg-red-50 p-4 rounded-lg shadow-md my-4 text-slate-800 border border-red-200">
            <p className="text-red-700 font-semibold">{uiTexts.errorMessageDefault}</p>
            <p className="text-red-600 mt-1">{message.text}</p>
        </div>
    );
  }
  
  const webSources = message.sources?.filter(s => s.web).map(s => s.web!) || [];

  return (
    <div className="bg-white p-5 sm:p-6 rounded-xl shadow-xl my-5 response-card-print">
      <div className="relative">
        <SimpleMarkdownRenderer text={message.text} />
        
        <div className="absolute top-0 right-0 mt-0 mr-0 flex space-x-1 print-hidden">
          {browserSupportsSpeechSynthesis && message.text.trim().length > 0 && (
            <button
              type="button"
              onClick={handleToggleSpeak}
              className="p-2 rounded-full hover:bg-slate-100 focus:outline-none focus:ring-2 focus:ring-indigo-400"
              title={isSpeaking ? uiTexts.stopSpeakingResponse : uiTexts.speakResponse}
              aria-pressed={isSpeaking}
              aria-label={isSpeaking ? uiTexts.stopSpeakingResponse : uiTexts.speakResponse}
            >
              {isSpeaking 
                ? <SpeakerStopIcon className="text-red-600 w-5 h-5" /> 
                : <SpeakerPlayIcon className="text-slate-500 hover:text-indigo-600 w-5 h-5" />}
            </button>
          )}
          <button
              type="button"
              onClick={handlePrint}
              className="p-2 rounded-full hover:bg-slate-100 focus:outline-none focus:ring-2 focus:ring-indigo-400"
              title={uiTexts.printResponse}
              aria-label={uiTexts.printResponse}
            >
              <PrintIcon className="text-slate-500 hover:text-indigo-600 w-5 h-5" />
          </button>
          <button
              type="button"
              onClick={handleSave}
              className="p-2 rounded-full hover:bg-slate-100 focus:outline-none focus:ring-2 focus:ring-indigo-400"
              title={uiTexts.saveResponse}
              aria-label={uiTexts.saveResponse}
            >
              <SaveIcon className="text-slate-500 hover:text-indigo-600 w-5 h-5" />
          </button>
        </div>
      </div>

      {webSources.length > 0 && (
        <div className="mt-6 pt-4 border-t border-slate-200">
          <h4 className="text-sm font-semibold text-slate-600 mb-2">{uiTexts.sourcesTitle}</h4>
          {/* For screen view - with download icons */}
          <ul className="list-none pl-0 space-y-1 hidden sm:block md:block lg:block xl:block print:hidden">
            {webSources.map((source, index) => (
              source.uri ? <SourceLink key={`${source.uri}-${index}-interactive`} source={source} currentLanguage={currentLanguage} /> : null
            ))}
          </ul>
          {/* For print view - without download icons */}
           <ul className="list-none pl-0 space-y-1 hidden print:block">
            {webSources.map((source, index) => (
              source.uri ? <PrintableSourceLink key={`${source.uri}-${index}-print`} source={source} /> : null
            ))}
          </ul>
           {/* Fallback for very small screens where print:hidden on the above ul might not work as expected - ensure sources show */}
           <ul className="list-none pl-0 space-y-1 sm:hidden md:hidden lg:hidden xl:hidden print:hidden">
             {webSources.map((source, index) => (
                source.uri ? <SourceLink key={`${source.uri}-${index}-fallback`} source={source} currentLanguage={currentLanguage} /> : null
             ))}
           </ul>
        </div>
      )}
      {webSources.length === 0 && message.sources && message.sources.length > 0 && (
         <div className="mt-6 pt-4 border-t border-slate-200">
            <p className="text-sm text-slate-500">{uiTexts.noSources}</p>
         </div>
      )}
    </div>
  );
};

export default ResponseDisplay;