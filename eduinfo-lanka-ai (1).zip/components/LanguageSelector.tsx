
import React from 'react';
import { Language, LanguageOption } from '../types';
import { LANGUAGE_OPTIONS, UI_TEXTS } from '../constants';

interface LanguageSelectorProps {
  selectedLanguage: Language;
  onChangeLanguage: (language: Language) => void;
}

const LanguageSelector: React.FC<LanguageSelectorProps> = ({ selectedLanguage, onChangeLanguage }) => {
  const currentUiTexts = UI_TEXTS[selectedLanguage];
  return (
    <div className="flex items-center space-x-2">
      <label htmlFor="language-select" className="text-sm font-medium text-gray-700">
        {currentUiTexts.languageSelectorLabel}
      </label>
      <select
        id="language-select"
        value={selectedLanguage}
        onChange={(e) => onChangeLanguage(e.target.value as Language)}
        className="block w-full pl-3 pr-10 py-2 text-base border-gray-300 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm rounded-md shadow-sm"
      >
        {LANGUAGE_OPTIONS.map((option) => (
          <option key={option.code} value={option.code}>
            {option.name}
          </option>
        ))}
      </select>
    </div>
  );
};

export default LanguageSelector;
