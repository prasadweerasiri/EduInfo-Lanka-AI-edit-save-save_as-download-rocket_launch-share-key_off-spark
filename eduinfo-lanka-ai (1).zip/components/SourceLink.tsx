import React from 'react';
import { GroundingChunkWeb } from "@google/genai";
import { Language } from '../types';
import { UI_TEXTS } from '../constants';

interface SourceLinkProps {
  source: GroundingChunkWeb;
  currentLanguage: Language; // Added to get localized tooltip text
}

const DownloadFileIcon: React.FC<{ className?: string }> = ({ className }) => (
  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor" className={`w-5 h-5 ${className}`}>
    <path d="M10.75 2.75a.75.75 0 00-1.5 0v8.614L6.295 8.235a.75.75 0 10-1.09 1.03l4.25 4.5a.75.75 0 001.09 0l4.25-4.5a.75.75 0 10-1.09-1.03l-2.955 3.129V2.75z" />
    <path d="M3.5 12.75a.75.75 0 00-1.5 0v2.5A2.75 2.75 0 004.75 18h10.5A2.75 2.75 0 0018 15.25v-2.5a.75.75 0 00-1.5 0v2.5c0 .69-.56 1.25-1.25 1.25H4.75c-.69 0-1.25-.56-1.25-1.25v-2.5z" />
  </svg>
);

const SourceLink: React.FC<SourceLinkProps> = ({ source, currentLanguage }) => {
  if (!source.uri) {
    return null;
  }
  const uiTexts = UI_TEXTS[currentLanguage];

  return (
    <li className="mb-1 flex justify-between items-center group print-hidden">
      <a
        href={source.uri}
        target="_blank"
        rel="noopener noreferrer"
        className="flex-grow text-blue-600 hover:text-blue-800 hover:underline text-sm break-all mr-2"
        title={source.title || source.uri}
      >
        {source.title || source.uri}
      </a>
      {source.uri && (
        <a
          href={source.uri}
          download // Instructs the browser to download the linked resource
          className="p-1.5 text-slate-400 hover:text-indigo-600 focus:outline-none focus:ring-1 focus:ring-offset-1 focus:ring-indigo-500 rounded-full opacity-50 group-hover:opacity-100 focus:opacity-100 transition-opacity"
          title={uiTexts.downloadSourceFile}
          aria-label={uiTexts.downloadSourceFile}
          target="_blank" // keep target blank for safety, though download may override
          rel="noopener noreferrer" // Standard for security
        >
          <DownloadFileIcon className="w-4 h-4" />
        </a>
      )}
    </li>
  );
};

// Component for displaying in print (no download icon)
export const PrintableSourceLink: React.FC<Omit<SourceLinkProps, 'currentLanguage'>> = ({ source }) => {
  if (!source.uri) {
    return null;
  }
  return (
     <li className="mb-1">
      <a
        href={source.uri}
        className="text-blue-600 hover:text-blue-800 hover:underline text-sm break-all"
        title={source.title || source.uri}
      >
        {source.title || source.uri}
         {/* Optionally show full URI in print: <span className="text-xs text-gray-500 ml-1">({source.uri})</span> */}
      </a>
    </li>
  )
}


export default SourceLink;