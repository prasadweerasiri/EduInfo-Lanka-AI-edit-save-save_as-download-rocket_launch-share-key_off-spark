import { GoogleGenAI, GenerateContentResponse, GroundingChunk, Part } from "@google/genai";
import { GEMINI_MODEL_NAME, getSystemInstruction } from '../constants';
import { Language } from "../types";

const API_KEY = process.env.API_KEY;

let ai: GoogleGenAI;

if (API_KEY) {
  ai = new GoogleGenAI({ apiKey: API_KEY });
} else {
  console.error("API_KEY environment variable not set. Core functionalities will be impaired.");
  // Fallback for ai object to prevent crashes if API_KEY is missing
  // @ts-ignore // This is a deliberate fallback
  ai = { models: { generateContent: async () => Promise.reject(new Error("API_KEY_MISSING")) } };
}


export interface GeminiServiceResponse {
  text: string;
  sources?: GroundingChunk[];
}

export const fetchEducationalInfo = async (
  query: string,
  language: Language
): Promise<GeminiServiceResponse> => {
  if (!API_KEY || !ai) { // Check API_KEY again, as ai might be the fallback
    throw new Error("API_KEY_MISSING");
  }

  const systemInstruction = getSystemInstruction(language);
  const model = GEMINI_MODEL_NAME;
  
  const contents: Part[] = [{ text: query }];

  try {
    const response: GenerateContentResponse = await ai.models.generateContent({
      model: model,
      contents: contents,
      config: {
        systemInstruction: systemInstruction,
        tools: [{ googleSearch: {} }],
      },
    });
    
    const text = response.text;
    const sources = response.candidates?.[0]?.groundingMetadata?.groundingChunks;

    return { text, sources };

  } catch (error) {
    console.error("Error calling Gemini API for text generation:", error);
    if (error instanceof Error && error.message.includes("API_KEY_MISSING")) {
        throw new Error("API_KEY_MISSING");
    }
    if (error instanceof Error) {
        throw new Error(`Gemini API Error: ${error.message}`);
    }
    throw new Error("An unknown error occurred while fetching information from Gemini API.");
  }
};
// Image generation functions (generateImagePromptFromText, generateImageForResponse) have been removed.
